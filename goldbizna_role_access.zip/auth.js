
/* Goldbizna Role Access Control */
const GB_USERS = {
  admin:  { password: "admin123", role: "admin",  name: "Administrator" },
  cashier:{ password: "cashier123", role: "cashier", name: "Cashier" },
  stock:  { password: "stock123", role: "stock",  name: "Stock Manager" }
};

const GB_PERMISSIONS = {
  admin:   ["home","pos","inventory","customers","sales","savings","reports","users","settings"],
  cashier: ["home","pos","customers","sales"],
  stock:   ["home","pos","inventory","customers","sales"]
};

function gbSession() {
  try { return JSON.parse(localStorage.getItem("goldbizna_session") || "null"); }
  catch(e) { return null; }
}

function gbLogin(username, password) {
  const u = GB_USERS[username];
  if (!u || u.password !== password) return false;
  localStorage.setItem("goldbizna_session", JSON.stringify({
    username, name: u.name, role: u.role, loginAt: Date.now()
  }));
  return true;
}

function gbLogout() {
  localStorage.removeItem("goldbizna_session");
  location.href = "login.html";
}

function gbRequireLogin() {
  const s = gbSession();
  if (!s) {
    location.replace("login.html");
    return null;
  }
  return s;
}

function gbCan(page) {
  const s = gbSession();
  return !!(s && GB_PERMISSIONS[s.role] && GB_PERMISSIONS[s.role].includes(page));
}

function gbRequireRole(page) {
  const s = gbRequireLogin();
  if (!s) return;
  if (!gbCan(page)) {
    alert("Access denied. Your account is not allowed to open this section.");
    location.replace("index.html");
  }
}

function gbApplyMenuAccess() {
  const s = gbSession();
  if (!s) return;
  document.querySelectorAll("[data-page]").forEach(el => {
    const page = el.getAttribute("data-page");
    if (!gbCan(page)) el.style.display = "none";
  });
  const who = document.querySelector("[data-user-name]");
  if (who) who.textContent = s.name + " (" + s.role + ")";
}
