const express = require('express');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

const PORT = Number(process.env.PORT || 3000);
const MPESA_ENV = (process.env.MPESA_ENV || 'sandbox').toLowerCase();
const SHORTCODE = process.env.MPESA_SHORTCODE || '';
const PASSKEY = process.env.MPESA_PASSKEY || '';
const CONSUMER_KEY = process.env.MPESA_CONSUMER_KEY || '';
const CONSUMER_SECRET = process.env.MPESA_CONSUMER_SECRET || '';
const CALLBACK_URL = process.env.MPESA_CALLBACK_URL || '';
const statusStore = new Map();

const base = MPESA_ENV === 'production'
  ? 'https://api.safaricom.co.ke'
  : 'https://sandbox.safaricom.co.ke';

function normalizePhone(value) {
  let p = String(value || '').replace(/\D/g, '');
  if (p.startsWith('0')) p = '254' + p.slice(1);
  if (p.startsWith('7') || p.startsWith('1')) p = '254' + p;
  return p;
}

function timestamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return d.getFullYear() + pad(d.getMonth()+1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
}

async function getToken() {
  if (!CONSUMER_KEY || !CONSUMER_SECRET) throw new Error('M-Pesa consumer credentials are not configured');
  const auth = Buffer.from(`${CONSUMER_KEY}:${CONSUMER_SECRET}`).toString('base64');
  const r = await fetch(`${base}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` }
  });
  const data = await r.json();
  if (!r.ok || !data.access_token) throw new Error(data.errorMessage || 'Unable to obtain M-Pesa access token');
  return data.access_token;
}

app.post('/api/mpesa/stkpush', async (req, res) => {
  try {
    if (!SHORTCODE || !PASSKEY || !CALLBACK_URL) {
      return res.status(500).json({ success:false, message:'Configure MPESA_SHORTCODE, MPESA_PASSKEY and MPESA_CALLBACK_URL first.' });
    }
    const phone = normalizePhone(req.body.phone);
    const amount = Math.round(Number(req.body.amount || 0));
    if (!/^254(?:7|1)\\d{8}$/.test(phone)) return res.status(400).json({ success:false, message:'Enter a valid Kenyan M-Pesa number.' });
    if (!amount || amount < 1) return res.status(400).json({ success:false, message:'Invalid payment amount.' });

    const token = await getToken();
    const ts = timestamp();
    const password = Buffer.from(`${SHORTCODE}${PASSKEY}${ts}`).toString('base64');
    const payload = {
      BusinessShortCode: SHORTCODE,
      Password: password,
      Timestamp: ts,
      TransactionType: 'CustomerPayBillOnline',
      Amount: amount,
      PartyA: phone,
      PartyB: SHORTCODE,
      PhoneNumber: phone,
      CallBackURL: CALLBACK_URL,
      AccountReference: String(req.body.accountReference || 'MABROUK POS').slice(0, 20),
      TransactionDesc: String(req.body.transactionDesc || 'POS SALE').slice(0, 20)
    };

    const r = await fetch(`${base}/mpesa/stkpush/v1/processrequest`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type':'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await r.json();
    if (!r.ok || data.ResponseCode !== '0') {
      return res.status(502).json({ success:false, message:data.errorMessage || data.ResponseDescription || 'Safaricom rejected the STK request.' });
    }
    statusStore.set(data.CheckoutRequestID, { status:'PENDING', createdAt:Date.now() });
    res.json({ success:true, checkoutRequestID:data.CheckoutRequestID, merchantRequestID:data.MerchantRequestID, responseDescription:data.ResponseDescription });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success:false, message:e.message || 'M-Pesa request failed' });
  }
});

app.post('/api/mpesa/callback', (req, res) => {
  const body = req.body || {};
  const cb = body.Body && body.Body.stkCallback;
  if (cb && cb.CheckoutRequestID) {
    const ok = Number(cb.ResultCode) === 0;
    let receipt = '';
    if (ok && Array.isArray(cb.CallbackMetadata?.Item)) {
      const item = cb.CallbackMetadata.Item.find(x => x.Name === 'MpesaReceiptNumber');
      receipt = item?.Value ? String(item.Value) : '';
    }
    statusStore.set(cb.CheckoutRequestID, {
      status: ok ? 'SUCCESS' : 'FAILED',
      resultCode: Number(cb.ResultCode),
      message: cb.ResultDesc || '',
      mpesaCode: receipt,
      updatedAt: Date.now()
    });
  }
  res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
});

app.get('/api/mpesa/status', (req, res) => {
  const id = String(req.query.checkoutRequestID || '');
  const status = statusStore.get(id);
  if (!status) return res.json({ status:'PENDING' });
  res.json(status);
});

app.listen(PORT, () => console.log(`MABROUK POS running on http://localhost:${PORT}`));
