function goldbiznaLogout(){
    sessionStorage.removeItem("goldbizna_authenticated");
    location.href="login.html";
}