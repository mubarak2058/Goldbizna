GOLDBIZNA POS PRO - MULTI-PAYMENT UPGRADE

GitHub Pages-ready static website.

Includes:
- One login password plus a user name.
- Cash, M-Pesa, Card, Bank and Split Payment options.
- M-Pesa waiting/confirmation workflow: the POS asks for confirmation that the named customer paid the sale amount before the sale is finalized.
- M-Pesa transaction details are NOT printed on the customer receipt.
- Receipt shows: "You were served by: [user name]".
- Sales history stores the serving user's name and payment method.

IMPORTANT M-PESA LIMITATION:
The browser package cannot directly read private transactions arriving at a real Safaricom Till. Automatic Till matching requires a server-side Safaricom Daraja integration and callback/webhook endpoint. Never put Daraja secrets in GitHub Pages HTML/JavaScript.

Official Safaricom Daraja portal:
https://developer.safaricom.co.ke/
