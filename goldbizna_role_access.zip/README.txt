GOLDBIZNA ROLE ACCESS
======================

1. Upload all files to the same GitHub Pages folder.
2. Open login.html.
3. Demo accounts:
   admin / admin123       -> everything
   cashier / cashier123   -> POS, Customers, Sales
   stock / stock123       -> POS, Inventory, Customers, Sales

4. Change usernames/passwords in auth.js before real use.

IMPORTANT:
This is role-based access for a static GitHub Pages website. It hides menu items and blocks direct page navigation in the browser, but it is NOT strong server-side security. For real business data and sensitive admin functions, use Firebase or another backend with server-side authorization.
