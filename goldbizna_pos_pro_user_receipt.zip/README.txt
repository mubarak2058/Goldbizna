GOLDBIZNA POS PRO
==================
Upload all HTML files to the same GitHub Pages folder.

Login password: 1234

Navigation:
Home, POS, Inventory, Customers, Sales, Savings, Reports, Users, Settings, Logout.

Demo data is stored in the browser localStorage.
