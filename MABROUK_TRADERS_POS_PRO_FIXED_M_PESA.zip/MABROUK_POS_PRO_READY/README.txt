MABROUK TRADER'S POS PRO — FIXED EDITION

WHAT WAS CHANGED
1. The page itself no longer scrolls.
2. Only the cart item area scrolls.
3. POS action/payment buttons stay visible.
4. There is only ONE Customer Name field. It also searches saved customers.
5. After adding a product, the cursor automatically returns to Search Product.
6. M-Pesa STK Push is wired to /api/mpesa/stkpush and waits for the callback result.
7. Inventory stock continues to update through Firebase after a completed sale.

M-PESA SETUP
This POS cannot safely contain Safaricom consumer secrets in the browser. The included server.js keeps those credentials on the server and calls Daraja.

1. Install Node.js 18+.
2. Run: npm install
3. Copy .env.example to .env
4. Put your Daraja credentials in .env.
5. MPESA_CALLBACK_URL must be a publicly reachable HTTPS URL ending in /api/mpesa/callback.
6. Run: npm start
7. Open: http://localhost:3000

For local testing, expose the server through a secure public HTTPS tunnel so Safaricom can reach the callback.

The included implementation uses Daraja STK Push. Production credentials and a production callback URL are required for live payments.
